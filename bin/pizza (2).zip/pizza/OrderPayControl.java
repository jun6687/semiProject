package pizza;

class OrderPayControl {
	BasketUI basket; //참조변수 이름추천좀..
	
	OrderPayControl(BasketUI basket){
		this.basket = basket;
		
	}
}
