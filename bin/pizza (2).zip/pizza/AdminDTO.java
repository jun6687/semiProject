package pizza;

public class AdminDTO {
	private int indexi;
	private String Timei;
	private String PizzaName;
	private String Address;
	private String delCheck;
	private int price;


	public int getindexi() {
		return indexi;
	}
	
	public void setindexi(int indexi) {
		this.indexi = indexi	;
	}
	
	public String getTimei() {
		return Timei;
	}
	
	public void setTimei(String Timei) {
		this.Timei = Timei	;
	}
	
	public String getPizzaName() {
		return PizzaName;
	}
	
	public void setPizzaName(String PizzaName) {
		this.PizzaName = PizzaName	;
	}
	
	public String getAddress() {
		return Address;
	}
	
	public void setAddress(String Address) {
		this.Address = Address	;
	}
	
	public String getdelCheck() {
		return delCheck;
	}
	
	public void setdelCheck(String delCheck) {
		this.delCheck = delCheck	;
	}
	
	public int getprice() {
		return price;
	}
	
	public void setprice(int price) {
		this.price = price	;
	}
}
