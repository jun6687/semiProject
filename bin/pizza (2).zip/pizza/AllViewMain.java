package pizza;

public class AllViewMain {
	public static void main(String[] args) {

		new FirstUI();
		

		
		
		 /************TEAM************
		 * 박세준 :: 프로젝트 총괄
		 * 박준일 :: DB담당
		 * 안은지 :: UI 담당
		 * 배정언 :: UI 담당
		 * 김우현 :: UI 총괄, Control Support
		 * Our Project :: https://github.com/pkt369/PizzaProject
		 *****************************/

	}
}
