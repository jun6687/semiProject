package pizza;

import javax.swing.JFrame;

class OrderPayUI extends JFrame{
	
}
